package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.model.Staff;

public class Dao {

	public ArrayList<Staff> m1() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbk", "root", "root");
		Statement stmt = con.createStatement();
		String sql = "select * from staff";
		ResultSet jbk = stmt.executeQuery(sql);
		ArrayList<Staff> al = new ArrayList<>();
		while (jbk.next()) {
			int id = jbk.getInt(1);
			String name = jbk.getString("name");
			String salary = jbk.getString(3);
			String des = jbk.getString("des");
			Staff s = new Staff();
			s.setId(id);
			s.setName(name);
			s.setSalary(salary);
			s.setDes(des);
			al.add(s);
		}
		return al;
	}

	public String insertStaffRecord(int id, String name, String salary, String des) throws ClassNotFoundException, SQLException {
	
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/jbk", "root", "root");
		/*
		 * Statement stmt = con.createStatement(); String sql =
		 * "insert into staff (id,salary,name,des) values (7,'10000','satya','IT')"; int
		 * isInserted = stmt.executeUpdate(sql);
		 * 
		 * System.out.println(isInserted);
		 * 
		 */
		String sql = "insert into staff (id,name,salary,des) values (?,?,?,?)";
		
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.setString(3, salary);
		ps.setString(4, des);
		int isInserted = ps.executeUpdate();
		return "Data Inserted Successfully";
	}



}
