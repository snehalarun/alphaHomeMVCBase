package com.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import com.model.Staff;
import com.service.Service;

public class Controoler {

	void m1() throws ClassNotFoundException, SQLException {
		Service s = new Service();
		ArrayList<Staff> al = s.m1();
		System.out.println(al);
	}

	void insertStaffRecord() throws ClassNotFoundException, SQLException {

		Service ss = new Service();
		String msg = ss.insertStaffRecord(11, "sham", "20000", "Dev");
		System.out.println(msg);
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Controoler cc = new Controoler();
		cc.insertStaffRecord();
	}
}
