package com.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.dao.Dao;
import com.model.Staff;

public class Service {

	public ArrayList<Staff> m1() throws ClassNotFoundException, SQLException {
		Dao d = new Dao();
		ArrayList<Staff> al = d.m1();
		
		System.out.println("In Service : "+al);
		return al;
	}

	public String insertStaffRecord(int id, String name, String salary, String des) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Dao dd = new Dao();
	String mssg =	dd.insertStaffRecord(id,name,salary,des);
		return mssg;
		
	}
}
